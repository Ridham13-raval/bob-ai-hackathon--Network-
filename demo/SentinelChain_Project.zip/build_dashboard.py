"""Build the single-file control-tower dashboard from out/results.json."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = json.load(open(os.path.join(HERE, "out", "results.json")))

HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SentinelChain — control tower</title>
<style>
:root{
  --sea:#06161E; --deck:#0D2733; --deck2:#123342; --rule:#1E4759;
  --ink:#DCE9ED; --mute:#7EA0AD; --dim:#4E7183;
  --starboard:#2DBE7E; --port:#E0435B; --amber:#E8A33D; --ice:#6FD3E8;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  background:var(--sea); color:var(--ink);
  font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size:14px; line-height:1.5;
  -webkit-font-smoothing:antialiased;
}
.num{font-family:ui-monospace,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace;
     font-variant-numeric:tabular-nums}
a{color:var(--ice)}
.wrap{max-width:1280px;margin:0 auto;padding:0 28px 72px}

/* ---------- masthead ---------- */
header{border-bottom:1px solid var(--rule);margin-bottom:26px}
.mast{display:flex;align-items:flex-end;justify-content:space-between;
      gap:24px;padding:26px 0 18px;flex-wrap:wrap}
.brand h1{font-size:27px;margin:0;font-weight:600;letter-spacing:-.02em}
.brand p{margin:5px 0 0;color:var(--mute);max-width:52ch}
.stamp{text-align:right;color:var(--dim);font-size:12px}
.stamp b{display:block;color:var(--ink);font-size:15px;font-weight:500}

/* ---------- ask ---------- */
.ask{display:flex;gap:10px;padding:0 0 20px}
.ask input{flex:1;background:var(--deck);border:1px solid var(--rule);
  color:var(--ink);padding:11px 14px;font-size:14px;border-radius:3px;
  font-family:inherit}
.ask input:focus{outline:2px solid var(--ice);outline-offset:-1px}
.ask button{background:var(--ice);color:#06161E;border:0;padding:11px 20px;
  font-size:14px;font-weight:600;border-radius:3px;cursor:pointer;font-family:inherit}
.answer{background:var(--deck);border:1px solid var(--rule);border-radius:3px;
  padding:14px 16px;margin-bottom:22px;display:none}
.answer .tool{color:var(--dim);font-size:12px;margin-bottom:8px}
.answer p{margin:0 0 7px}

/* ---------- ribbon ---------- */
.ribbon{background:var(--deck);border:1px solid var(--rule);border-radius:3px;
  padding:18px 20px 8px;margin-bottom:22px}
.ribbon h2{margin:0;font-size:15px;font-weight:600}
.ribbon .sub{color:var(--mute);font-size:12.5px;margin:3px 0 12px}
svg{display:block;width:100%;height:auto}
.dot{cursor:pointer;transition:opacity .15s}
.dot:hover{stroke:#fff;stroke-width:1.4}

/* ---------- kpis ---------- */
.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:1px;
  background:var(--rule);border:1px solid var(--rule);border-radius:3px;
  overflow:hidden;margin-bottom:26px}
.kpi{background:var(--deck);padding:15px 16px}
.kpi .v{font-size:24px;font-weight:600;letter-spacing:-.02em}
.kpi .l{color:var(--mute);font-size:12px;margin-top:3px}
.kpi.hi .v{color:var(--starboard)}

/* ---------- layout ---------- */
.cols{display:grid;grid-template-columns:268px 1fr;gap:22px;align-items:start}
.rail h3,.panel h3{font-size:12.5px;color:var(--mute);font-weight:600;
  margin:0 0 10px}
.inc{background:var(--deck);border:1px solid var(--rule);border-left-width:1px;
  border-radius:3px;padding:12px 13px;margin-bottom:9px;cursor:pointer;
  transition:background .12s}
.inc:hover{background:var(--deck2)}
.inc.on{background:var(--deck2);box-shadow:inset 0 0 0 1px var(--ice)}
.inc .k{font-size:11.5px;color:var(--dim)}
.inc .h{font-size:13px;margin:3px 0 7px;line-height:1.35}
.inc .m{font-size:11.5px;color:var(--mute)}
.sev{display:inline-block;width:7px;height:7px;border-radius:50%;
  margin-right:6px;vertical-align:middle}

/* ---------- tabs ---------- */
.tabs{display:flex;gap:2px;border-bottom:1px solid var(--rule);margin-bottom:16px}
.tab{background:none;border:0;color:var(--mute);padding:9px 15px;font-size:13.5px;
  cursor:pointer;border-bottom:2px solid transparent;font-family:inherit}
.tab.on{color:var(--ink);border-bottom-color:var(--ice)}
.view{display:none}
.view.on{display:block}

/* ---------- tables ---------- */
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;color:var(--mute);font-weight:500;font-size:11.5px;
   padding:7px 10px;border-bottom:1px solid var(--rule)}
td{padding:9px 10px;border-bottom:1px solid rgba(30,71,89,.55);vertical-align:top}
tr.row{cursor:pointer}
tr.row:hover td{background:var(--deck)}
.r{text-align:right}
.pill{display:inline-block;padding:1px 7px;border-radius:2px;font-size:11px;
  font-weight:600}
.p-red{background:rgba(224,67,91,.16);color:#FF7C8C}
.p-orange{background:rgba(232,163,61,.16);color:#F2BA62}
.p-amber{background:rgba(232,163,61,.12);color:#D8A55C}
.p-green{background:rgba(45,190,126,.14);color:#57D69A}
.p-ice{background:rgba(111,211,232,.14);color:var(--ice)}
.detail td{background:#0A1F29;padding:0}
.detail .inner{padding:14px 16px}
.opt{display:grid;grid-template-columns:1.6fr .8fr .8fr .8fr 1fr;gap:10px;
  padding:7px 0;border-bottom:1px solid rgba(30,71,89,.45);font-size:12.5px}
.opt.head{color:var(--mute);font-size:11.5px;border-bottom:1px solid var(--rule)}
.opt.best{color:var(--starboard)}
.why{color:var(--mute);font-size:12.5px;margin:9px 0 0;max-width:86ch}
.bar{height:5px;background:var(--rule);border-radius:3px;overflow:hidden;
  min-width:56px;margin-top:5px}
.bar i{display:block;height:100%}
.trace{margin-top:12px}
.note{color:var(--dim);font-size:12px;margin-top:14px}
.empty{color:var(--mute);padding:26px 10px}
footer{margin-top:40px;padding-top:16px;border-top:1px solid var(--rule);
  color:var(--dim);font-size:12px}
@media (max-width:900px){
  .cols{grid-template-columns:1fr}
  .kpis{grid-template-columns:repeat(2,1fr)}
  .opt{grid-template-columns:1fr 1fr}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
<header>
  <div class="mast">
    <div class="brand">
      <h1>SentinelChain</h1>
      <p>Four active disruptions, __NSHIP__ shipments in flight, one question that
         matters: what do we move, and what do we save?</p>
    </div>
    <div class="stamp">operating picture as of<b id="stamp"></b></div>
  </div>
</header>

<div class="ask">
  <input id="q" placeholder="Ask the agent — e.g. which vaccine shipments have a temperature problem?">
  <button id="go">Ask</button>
</div>
<div class="answer" id="ans"></div>

<div class="ribbon">
  <h2>When each exposed shipment hits its blocked node</h2>
  <p class="sub">Horizontal axis is days from now. Vertical is exposure score.
     Everything left of the dashed line needs a decision this week.</p>
  <svg id="ribbon" viewBox="0 0 1000 220" role="img"
       aria-label="Timeline of exposed shipments by days until they reach a blocked node"></svg>
</div>

<div class="kpis" id="kpis"></div>

<div class="cols">
  <aside class="rail">
    <h3>Active incidents</h3>
    <div id="incs"></div>
    <p class="note" id="filternote">Showing all incidents. Select one to filter.</p>
  </aside>

  <section class="panel">
    <div class="tabs">
      <button class="tab on" data-v="exp">Exposure</button>
      <button class="tab" data-v="rec">Decisions</button>
      <button class="tab" data-v="flt">Fleet</button>
      <button class="tab" data-v="cc">Cold chain</button>
    </div>
    <div class="view on" id="v-exp"></div>
    <div class="view" id="v-rec"></div>
    <div class="view" id="v-flt"></div>
    <div class="view" id="v-cc"></div>
  </section>
</div>

<footer>
  SentinelChain runs four deterministic engines — exposure scoring, re-route
  optimisation, fleet redeployment, cold-chain classification — behind an agent
  that chooses which to call. Every figure on this page is computed, not stored.
  Dataset is synthetic and seeded for reproducibility.
</footer>
</div>

<script id="payload" type="application/json">__DATA__</script>
<script>
const D = JSON.parse(document.getElementById('payload').textContent);
let filter = null;

const usd = n => '$' + Math.round(n).toLocaleString('en-US');
const usdS = n => n >= 1e6 ? '$' + (n/1e6).toFixed(2) + 'M'
              : n >= 1e3 ? '$' + Math.round(n/1e3) + 'k' : '$' + Math.round(n);
const NICE = {vaccine_2_8:'vaccine (2–8°C)', biologic_frozen:'frozen biologic',
  perishable_food:'perishable food', pharma_ambient:'pharma (ambient)',
  electronics:'electronics', automotive:'automotive'};
const nice = c => NICE[c] || c.replace(/_/g,' ');
const esc = s => String(s).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const KIND_COLOR = {geopolitical:'#E0435B', port_strike:'#E8A33D',
                    weather:'#6FD3E8', congestion:'#2DBE7E'};

document.getElementById('stamp').textContent =
  new Date(D.generated_at).toUTCString().slice(5, 22) + ' UTC';

/* ---------------- KPIs ---------------- */
const k = D.kpis;
document.getElementById('kpis').innerHTML = [
  [usdS(k.value_at_risk_usd), 'value at risk right now', ''],
  [k.shipments_exposed + ' / ' + k.shipments_monitored, 'shipments exposed', ''],
  [usdS(k.reroute_savings_usd), 'saved by re-routing', 'hi'],
  ['+' + k.utilisation_uplift_pts + ' pts', 'fleet utilisation', 'hi'],
  [usdS(k.cold_chain_value_protected_usd), 'cold cargo caught in time', 'hi'],
].map(([v,l,c]) => `<div class="kpi ${c}"><div class="v num">${v}</div>
   <div class="l">${l}</div></div>`).join('');

/* ---------------- Ribbon ---------------- */
function ribbon(){
  const W = 1000, H = 220, ml = 44, mr = 16, mt = 14, mb = 28;
  const pts = D.exposures.filter(e => !filter || e.disruption_id === filter);
  const maxD = 35;
  const x = d => ml + Math.min(d, maxD) / maxD * (W - ml - mr);
  const y = s => mt + (100 - s) / 55 * (H - mt - mb);
  let s = '';
  for (let d = 0; d <= maxD; d += 7){
    s += `<line x1="${x(d)}" y1="${mt}" x2="${x(d)}" y2="${H-mb}"
           stroke="#1E4759" stroke-width="1"/>
          <text x="${x(d)}" y="${H-10}" fill="#4E7183" font-size="11"
           text-anchor="middle" font-family="monospace">${d===0?'now':'+'+d+'d'}</text>`;
  }
  [50,70,90].forEach(v => {
    s += `<text x="${ml-8}" y="${y(v)+4}" fill="#4E7183" font-size="11"
           text-anchor="end" font-family="monospace">${v}</text>`;
  });
  s += `<line x1="${x(7)}" y1="${mt}" x2="${x(7)}" y2="${H-mb}" stroke="#6FD3E8"
         stroke-width="1" stroke-dasharray="4 4"/>`;
  pts.forEach(e => {
    const r = 3 + Math.min(7, e.value_usd / 260000);
    s += `<circle class="dot" cx="${x(e.days_until_choke)}" cy="${y(e.exposure_score)}"
           r="${r.toFixed(1)}" fill="${KIND_COLOR[e.kind]}" fill-opacity="${e.sla_breach?.85:.4}">
           <title>${e.shipment_id} · ${e.customer} · ${usd(e.value_usd)}
· hits ${e.choke_node} in ${e.days_until_choke}d · score ${e.exposure_score}</title></circle>`;
  });
  document.getElementById('ribbon').innerHTML = s;
}

/* ---------------- Incident rail ---------------- */
function rail(){
  const by = {}; D.disruption_rollup.forEach(r => by[r.disruption_id] = r);
  document.getElementById('incs').innerHTML = D.disruptions.map(d => {
    const r = by[d.disruption_id] || {shipments:0, value_at_risk:0, cold_chain:0};
    return `<div class="inc ${filter===d.disruption_id?'on':''}" data-id="${d.disruption_id}">
      <div class="k"><span class="sev" style="background:${KIND_COLOR[d.kind]}"></span>
        ${d.disruption_id} · ${d.kind.replace('_',' ')}</div>
      <div class="h">${esc(d.headline)}</div>
      <div class="m num">${r.shipments} shipments · ${usdS(r.value_at_risk)} ·
        ${r.cold_chain} cold</div>
      <div class="bar"><i style="width:${(d.severity*100).toFixed(0)}%;
        background:${KIND_COLOR[d.kind]}"></i></div>
    </div>`;
  }).join('');
  document.querySelectorAll('.inc').forEach(el => el.onclick = () => {
    filter = filter === el.dataset.id ? null : el.dataset.id;
    document.getElementById('filternote').textContent = filter
      ? 'Filtered to ' + filter + '. Select again to clear.'
      : 'Showing all incidents. Select one to filter.';
    render();
  });
}

/* ---------------- Exposure ---------------- */
function vExp(){
  const seen = new Set();
  const rows = D.exposures
    .filter(e => !filter || e.disruption_id === filter)
    .filter(e => !seen.has(e.shipment_id) && seen.add(e.shipment_id))
    .slice(0, 22);
  if (!rows.length) return '<p class="empty">No exposed shipments for this incident.</p>';
  return `<table><thead><tr>
    <th>Shipment</th><th>Customer</th><th>Cargo</th><th class="r">Value</th>
    <th>Blocked at</th><th class="r">Hits in</th><th class="r">Late by</th>
    <th class="r">Score</th></tr></thead><tbody>` +
  rows.map(e => `<tr>
    <td class="num">${e.shipment_id}</td>
    <td>${esc(e.customer)}</td>
    <td>${nice(e.commodity_class)}</td>
    <td class="r num">${usd(e.value_usd)}</td>
    <td>${e.choke_node}</td>
    <td class="r num">${e.days_until_choke}d</td>
    <td class="r num">${e.sla_breach
        ? '<span class="pill p-red">+' + e.projected_late_days.toFixed(1) + 'd</span>'
        : '<span class="pill p-green">on time</span>'}</td>
    <td class="r num"><b>${e.exposure_score}</b></td></tr>`).join('') +
  `</tbody></table><p class="note">Score blends value at risk, SLA headroom,
   cargo fragility, incident severity and time-to-choke. Top ${rows.length} of
   ${new Set(D.exposures.map(e=>e.shipment_id)).size} exposed shipments shown;
   a shipment blocked by two incidents is listed once, under its worst.</p>`;
}

/* ---------------- Decisions ---------------- */
function vRec(){
  const rows = D.recommendations.filter(r => !filter || r.disruption_id === filter);
  if (!rows.length) return '<p class="empty">No decisions queued for this incident.</p>';
  const total = rows.reduce((a,r) => a + Math.max(0, r.savings_vs_hold_usd), 0);
  return `<table><thead><tr>
    <th>Shipment</th><th>Recommended action</th><th class="r">Extra cost</th>
    <th class="r">Saves vs. hold</th><th class="r">Confidence</th><th></th>
    </tr></thead><tbody>` +
  rows.map((r,i) => `<tr class="row" data-x="r${i}">
    <td class="num">${r.shipment_id}<br><span style="color:var(--mute)">
      ${esc(r.customer)}</span></td>
    <td>${esc(r.recommendation)}${r.air_capacity_constrained
      ? '<br><span style="color:var(--mute);font-size:11.5px">air was cheaper but capacity was gone</span>' : ''}</td>
    <td class="r num">${usd(r.incremental_cost_usd)}</td>
    <td class="r num" style="color:var(--starboard)">${usd(r.savings_vs_hold_usd)}</td>
    <td class="r num">${(r.confidence*100).toFixed(0)}%</td>
    <td class="r">${r.requires_human_approval
        ? '<span class="pill p-amber">needs sign-off</span>'
        : '<span class="pill p-ice">auto</span>'}</td></tr>
    <tr class="detail" id="r${i}" style="display:none"><td colspan="6"><div class="inner">
      <div class="opt head"><span>Option</span><span class="r">Transit</span>
        <span class="r">Extra cost</span><span class="r">Spoilage risk</span>
        <span class="r">Total expected cost</span></div>
      ${r.options.map((o,j) => `<div class="opt ${j===0?'best':''}">
        <span>${esc(o.label)}</span>
        <span class="r num">${o.added_transit_days>0?'+':''}${o.added_transit_days}d</span>
        <span class="r num">${usd(o.incremental_cost_usd)}</span>
        <span class="r num">${(o.spoilage_prob*100).toFixed(1)}%</span>
        <span class="r num">${usd(o.total_expected_cost_usd)}</span></div>`).join('')}
      <p class="why">${esc(r.rationale)}</p></div></td></tr>`).join('') +
  `</tbody></table><p class="note">Options are ranked on expected total cost —
   SLA penalty plus spoilage plus incremental freight — so "do nothing" always
   competes. Combined saving on this view: <b class="num">${usd(total)}</b>.</p>`;
}

/* ---------------- Fleet ---------------- */
function vFlt(){
  const u = D.utilisation;
  const head = `<table><thead><tr><th>Asset</th><th>Type</th>
    <th>Move</th><th class="r">Distance</th><th class="r">Cost to move</th>
    <th class="r">Idle days ended</th><th class="r">Net benefit</th>
    </tr></thead><tbody>` +
   D.redeployment_plan.slice(0,16).map(p => `<tr>
     <td class="num">${p.asset_id}</td>
     <td>${p.kind.replace(/_/g,' ')}</td>
     <td>${p.distance_km === 0 ? esc(p.from_name) + ' — already on site'
          : esc(p.from_name) + ' → ' + esc(p.to_name)}</td>
     <td class="r num">${p.distance_km.toLocaleString()} km</td>
     <td class="r num">${usd(p.repositioning_cost_usd)}</td>
     <td class="r num">${p.idle_days_ended.toFixed(1)}</td>
     <td class="r num" style="color:var(--starboard)">${usd(p.net_benefit_usd)}</td>
     </tr>`).join('') + '</tbody></table>';
  return `<div class="kpis" style="grid-template-columns:repeat(4,1fr);margin-bottom:18px">
    <div class="kpi"><div class="v num">${u.idle_flagged}</div>
      <div class="l">assets idle past threshold</div></div>
    <div class="kpi"><div class="v num">${usdS(u.idle_carrying_cost_usd)}</div>
      <div class="l">carrying cost already burned</div></div>
    <div class="kpi hi"><div class="v num">${u.assets_redeployed}</div>
      <div class="l">redeployed for ${usdS(u.repositioning_spend_usd)}</div></div>
    <div class="kpi hi"><div class="v num">${(u.utilisation_before*100).toFixed(0)}%
      → ${(u.utilisation_after*100).toFixed(0)}%</div>
      <div class="l">fleet utilisation</div></div>
  </div>` + head + `<p class="note">Demand comes from the re-route engine: a box
   diverted via Durban needs a reefer at Durban. Assets are matched cheapest-first
   on value released minus repositioning cost.</p>`;
}

/* ---------------- Cold chain ---------------- */
function trace(r){
  const W=760,H=150,ml=38,mr=10,mt=10,mb=20, t=r.trace;
  if(!t) return '';
  const vs=t.map(p=>p.v), lo=Math.min(...vs,r.band[0])-1.5, hi=Math.max(...vs,r.band[1])+1.5;
  const x=i=>ml+i/(t.length-1)*(W-ml-mr), y=v=>mt+(hi-v)/(hi-lo)*(H-mt-mb);
  const band=`<rect x="${ml}" y="${y(r.band[1])}" width="${W-ml-mr}"
    height="${Math.max(2,y(r.band[0])-y(r.band[1]))}" fill="#2DBE7E" fill-opacity=".13"/>`;
  const line=t.map((p,i)=>(i?'L':'M')+x(i).toFixed(1)+' '+y(p.v).toFixed(1)).join(' ');
  const labs=[r.band[1],r.band[0]].map(v=>`<text x="${ml-6}" y="${y(v)+4}"
    fill="#7EA0AD" font-size="10" text-anchor="end" font-family="monospace">${v}°</text>`).join('');
  return `<svg class="trace" viewBox="0 0 ${W} ${H}" role="img"
    aria-label="Temperature profile for ${r.shipment_id}">${band}${labs}
    <path d="${line}" fill="none" stroke="#6FD3E8" stroke-width="1.6"/>
    <text x="${ml}" y="${H-5}" fill="#4E7183" font-size="10"
      font-family="monospace">${t[0].t} → ${t[t.length-1].t} (last 72h)</text></svg>`;
}
function vCc(){
  const s = D.cold_chain_summary, c = s.counts;
  const rows = D.cold_chain.filter(r => r.severity !== 'GREEN' || r.excursion_count > 0)
                           .concat(D.cold_chain.filter(r => r.severity === 'GREEN').slice(0,3));
  return `<div class="kpis" style="grid-template-columns:repeat(4,1fr);margin-bottom:18px">
    <div class="kpi"><div class="v num">${s.monitored}</div>
      <div class="l">cold shipments monitored</div></div>
    <div class="kpi"><div class="v num">
      <span style="color:var(--port)">${c.RED}</span> /
      <span style="color:var(--amber)">${c.ORANGE}</span> /
      <span style="color:#D8A55C">${c.AMBER}</span> /
      <span style="color:var(--starboard)">${c.GREEN}</span></div>
      <div class="l">red / orange / amber / green</div></div>
    <div class="kpi hi"><div class="v num">${s.caught_pre_delivery} of ${s.flagged}</div>
      <div class="l">flagged while still in transit</div></div>
    <div class="kpi hi"><div class="v num">${usdS(s.value_protected_usd)}</div>
      <div class="l">cargo value with an open intervention window</div></div>
  </div>
  <table><thead><tr><th>Shipment</th><th>Label range</th><th class="r">MKT</th>
    <th class="r">Time out of range</th><th class="r">Budget used</th>
    <th>Severity</th><th class="r">To delivery</th></tr></thead><tbody>` +
  rows.map((r,i) => `<tr class="row" data-x="c${i}">
    <td class="num">${r.shipment_id}<br><span style="color:var(--mute)">
      ${esc(r.customer)} · ${usd(r.value_usd)}</span></td>
    <td class="num">${r.label_range}</td>
    <td class="r num">${r.mkt_c}°C</td>
    <td class="r num">${r.tor_minutes} min</td>
    <td class="r num">${(r.budget_consumed_pct*100).toFixed(0)}%</td>
    <td><span class="pill p-${r.severity.toLowerCase()}">${r.severity}</span></td>
    <td class="r num">${r.hours_to_delivery.toFixed(0)}h</td></tr>
    <tr class="detail" id="c${i}" style="display:none"><td colspan="7"><div class="inner">
      <b>${esc(r.disposition)}</b>
      <p class="why">${r.reasons.map(esc).join(' ')}</p>
      <p class="why">Regulatory basis: ${esc(r.regulatory_hook)}.
         Peak ${r.peak_temp_c}°C, floor ${r.min_temp_c}°C across
         ${r.excursion_count} excursion window${r.excursion_count===1?'':'s'}.</p>
      ${trace(r)}</div></td></tr>`).join('') +
  `</tbody></table><p class="note">Mean Kinetic Temperature is the single
   isothermal temperature that would degrade the product as much as the observed
   profile did — it is what a regulator asks for, and it is why a short door-open
   blip and a nine-hour reefer failure do not get the same alarm.</p>`;
}

/* ---------------- Agent ask ---------------- */
const RULES = [
  [['cold','temperature','excursion','reefer','vaccine','mkt','spoil'], 'analyse_cold_chain'],
  [['idle','utilisation','utilization','redeploy','asset','fleet','truck','container'], 'propose_redeployment'],
  [['reroute','re-route','alternative','carrier','divert','option','air','ship it'], 'recommend_reroute'],
  [['impact','affected','exposed','disruption','strike','typhoon','risk','suez','delay'], 'assess_disruption_impact'],
];
function answer(q){
  const s = q.toLowerCase();
  let tool = 'assess_disruption_impact';
  for (const [keys, t] of RULES) if (keys.some(x => s.includes(x))) { tool = t; break; }
  let body = '';
  if (tool === 'analyse_cold_chain'){
    const hot = D.cold_chain.filter(r => r.severity === 'RED' || r.severity === 'ORANGE').slice(0,3);
    body = hot.map(r => `<p><b>${r.shipment_id}</b> — <span class="pill p-${r.severity.toLowerCase()}">
      ${r.severity}</span> MKT ${r.mkt_c}°C against a ${r.label_range} label,
      ${r.tor_minutes} min out of range (${(r.budget_consumed_pct*100).toFixed(0)}% of the
      stability budget). ${r.hours_to_delivery.toFixed(0)}h before delivery —
      ${esc(r.disposition)}</p>`).join('');
  } else if (tool === 'propose_redeployment'){
    body = D.redeployment_plan.slice(0,3).map(p => `<p><b>${p.asset_id}</b> —
      ${p.kind.replace(/_/g,' ')} idle ${p.idle_days_ended.toFixed(1)} days at
      ${esc(p.from_name)}. Move to ${esc(p.to_name)} for ${usd(p.repositioning_cost_usd)},
      net benefit ${usd(p.net_benefit_usd)}. Driver: ${esc(p.driver)}.</p>`).join('');
  } else if (tool === 'recommend_reroute'){
    body = D.recommendations.slice(0,3).map(r => `<p><b>${r.shipment_id}</b> —
      ${esc(r.recommendation)}. Saves ${usd(r.savings_vs_hold_usd)} against holding,
      costs ${usd(r.incremental_cost_usd)} extra, confidence
      ${(r.confidence*100).toFixed(0)}%.${r.requires_human_approval
        ? ' <span class="pill p-amber">proposal only — needs your sign-off</span>' : ''}</p>`).join('');
  } else {
    body = D.exposures.slice(0,4).map(e => `<p><b>${e.shipment_id}</b> (${esc(e.customer)})
      — ${usd(e.value_usd)} of ${nice(e.commodity_class)} reaches
      ${e.choke_node} in ${e.days_until_choke} days. Exposure ${e.exposure_score}.</p>`).join('');
  }
  const el = document.getElementById('ans');
  el.innerHTML = `<div class="tool num">agent → ${tool}()</div>` + body;
  el.style.display = 'block';
}
document.getElementById('go').onclick = () => answer(document.getElementById('q').value);
document.getElementById('q').addEventListener('keydown', e => {
  if (e.key === 'Enter') answer(e.target.value);
});

/* ---------------- Render ---------------- */
function bindRows(){
  document.querySelectorAll('tr.row').forEach(tr => tr.onclick = () => {
    const d = document.getElementById(tr.dataset.x);
    if (d) d.style.display = d.style.display === 'none' ? 'table-row' : 'none';
  });
}
function render(){
  ribbon(); rail();
  document.getElementById('v-exp').innerHTML = vExp();
  document.getElementById('v-rec').innerHTML = vRec();
  document.getElementById('v-flt').innerHTML = vFlt();
  document.getElementById('v-cc').innerHTML  = vCc();
  bindRows();
}
document.querySelectorAll('.tab').forEach(t => t.onclick = () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('on'));
  document.querySelectorAll('.view').forEach(x => x.classList.remove('on'));
  t.classList.add('on');
  document.getElementById('v-' + t.dataset.v).classList.add('on');
});
render();
</script>
</body>
</html>
"""

out = HTML.replace("__DATA__", json.dumps(DATA, separators=(",", ":"))) \
          .replace("__NSHIP__", str(DATA["kpis"]["shipments_monitored"]))
path = os.path.join(HERE, "out", "sentinelchain_dashboard.html")
open(path, "w").write(out)
print("wrote", path, round(len(out) / 1024), "KB")
