"""Render deck figures from out/results.json."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(HERE, "out", "results.json")))
FIG = os.path.join(HERE, "out")

SEA, DECK, ICE = "#06161E", "#0D2733", "#6FD3E8"
GREEN, RED, MUTE, INK = "#2DBE7E", "#E0435B", "#7EA0AD", "#DCE9ED"

# ---- temperature trace of the worst RED vaccine shipment -----------------
r = next(x for x in D["cold_chain"]
         if x["severity"] == "RED" and x.get("trace")
         and x["commodity_class"] == "vaccine_2_8")
t = r["trace"]
vals = [p["v"] for p in t]
lo, hi = r["band"]

fig, ax = plt.subplots(figsize=(10, 3.5), dpi=220)
fig.patch.set_facecolor(SEA)
ax.set_facecolor(SEA)
ax.add_patch(Rectangle((0, lo), len(vals) - 1, hi - lo,
                       facecolor=GREEN, alpha=0.16, zorder=0))
ax.axhline(hi, color=GREEN, lw=0.9, alpha=0.55)
ax.axhline(lo, color=GREEN, lw=0.9, alpha=0.55)
ax.plot(vals, color=ICE, lw=1.9, zorder=3)

out = [i for i, v in enumerate(vals) if v > hi or v < lo]
if out:
    a, b = min(out), max(out)
    ax.axvspan(a, b, color=RED, alpha=0.16, zorder=1)
    ax.annotate(f"{r['tor_minutes']} min out of range\n"
                f"{r['budget_consumed_pct']*100:.0f}% of stability budget",
                xy=((a + b) / 2, max(vals)), xytext=((a + b) / 2, max(vals) + 1.2),
                color=INK, fontsize=9, ha="center",
                arrowprops=dict(arrowstyle="-", color=MUTE, lw=0.8))

ax.set_ylim(min(vals) - 2, max(vals) + 3.4)
ax.set_xlim(0, len(vals) - 1)
ax.set_ylabel("°C", color=MUTE, fontsize=9)
ax.set_xticks([0, len(vals) // 2, len(vals) - 1])
ax.set_xticklabels(["72h ago", "36h ago", "now"], color=MUTE, fontsize=9)
ax.tick_params(colors=MUTE, labelsize=9)
for sp in ax.spines.values():
    sp.set_visible(False)
ax.text(0.5, hi + 0.25, f"label range {lo}–{hi}°C", color=GREEN, fontsize=8.5,
        va="bottom")
ax.text(len(vals) - 1, min(vals) - 1.6,
        f"{r['shipment_id']}  ·  MKT {r['mkt_c']}°C  ·  classified "
        f"{r['severity']}  ·  {r['hours_to_delivery']:.0f}h before delivery",
        color=MUTE, fontsize=8.5, ha="right")
fig.tight_layout()
p = os.path.join(FIG, "fig_trace.png")
fig.savefig(p, facecolor=SEA)
print("wrote", p, r["shipment_id"], r["severity"])
