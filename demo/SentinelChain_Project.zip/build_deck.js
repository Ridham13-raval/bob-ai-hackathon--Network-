const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

const D = JSON.parse(fs.readFileSync(path.join(__dirname, "out/results.json")));
const K = D.kpis, U = D.utilisation, C = D.cold_chain_summary;

const SEA = "06161E", DECK = "0D2733", DECK2 = "123342", RULE = "1E4759";
const INK = "DCE9ED", MUTE = "7EA0AD", DIM = "4E7183";
const ICE = "6FD3E8", GREEN = "2DBE7E", RED = "E0435B", AMBER = "E8A33D";

const HEAD = "Arial", BODY = "Calibri", MONO = "Courier New";
const W = 13.3, H = 7.5, M = 0.7;

const usd = n => "$" + Math.round(n).toLocaleString("en-US");
const usdM = n => n >= 1e6 ? "$" + (n / 1e6).toFixed(2) + "M"
  : "$" + Math.round(n / 1e3) + "k";

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";
pres.author = "SentinelChain";
pres.title = "SentinelChain — Supply Chain Disruption Assistant & Fleet Utilisation Optimizer";

function slide(notes) {
  const s = pres.addSlide();
  s.background = { color: SEA };
  if (notes) s.addNotes(notes);
  return s;
}

// Repeated motif: a small signal dot + monospace slide code, top-left.
function chip(s, code, color) {
  s.addShape(pres.ShapeType.ellipse, {
    x: M, y: 0.46, w: 0.11, h: 0.11, fill: { color: color || ICE },
  });
  s.addText(code, {
    x: M + 0.2, y: 0.36, w: 5, h: 0.3, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 11, color: DIM, valign: "middle",
  });
}

function title(s, text, sub) {
  s.addText(text, {
    x: M, y: 0.78, w: W - 2 * M, h: 0.72, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 32, bold: true, color: INK, valign: "middle",
  });
  if (sub) {
    s.addText(sub, {
      x: M, y: 1.5, w: W - 2 * M - 0.6, h: 0.44, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 14.5, color: MUTE,
    });
  }
}

function card(s, x, y, w, h, fill) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.04,
    fill: { color: fill || DECK }, line: { color: RULE, width: 1 },
  });
}

function stat(s, x, y, w, value, label, color) {
  card(s, x, y, w, 1.28);
  s.addText(value, {
    x: x + 0.22, y: y + 0.14, w: w - 0.44, h: 0.6, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 25, bold: true, color: color || INK, valign: "middle",
  });
  s.addText(label, {
    x: x + 0.22, y: y + 0.74, w: w - 0.44, h: 0.44, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 11.5, color: MUTE,
  });
}

function bullets(s, x, y, w, items, size, ls) {
  s.addText(items.map((t, i) => ({
    text: t, options: { bullet: true, breakLine: i < items.length - 1 },
  })), {
    x, y, w, h: 0.4 * items.length + 0.5, isTextBox: true,
    fontFace: BODY, fontSize: size || 14, color: INK,
    paraSpaceAfter: 6, lineSpacing: ls || 20,
  });
}

/* ==================================================================== 1 */
{
  const s = slide("Opening. 15 seconds: name, what it does, the number. " +
    "SentinelChain turns four disconnected feeds into one ranked decision queue. " +
    "On the seeded demo dataset it defends ten million dollars of cargo value in a single run.");
  s.addShape(pres.ShapeType.ellipse, {
    x: M, y: 2.28, w: 0.13, h: 0.13, fill: { color: ICE },
  });
  s.addText("Challenge L2 — Supply Chain Disruption Assistant & Fleet Utilisation Optimizer", {
    x: M + 0.24, y: 2.17, w: 9, h: 0.34, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 11.5, color: DIM, valign: "middle",
  });
  s.addText("SentinelChain", {
    x: M, y: 2.62, w: 10, h: 1.1, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 60, bold: true, color: INK,
  });
  s.addText("An agent that turns four disconnected feeds into one ranked decision queue — " +
    "and catches the cold-chain breach while the truck is still moving.", {
    x: M, y: 3.78, w: 8.6, h: 0.9, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 17, color: MUTE, lineSpacing: 26,
  });
  stat(s, M, 5.0, 2.6, usdM(K.total_value_defended_usd), "value defended per run", GREEN);
  stat(s, M + 2.75, 5.0, 2.6, String(K.shipments_monitored), "shipments monitored");
  stat(s, M + 5.5, 5.0, 2.6, C.caught_pre_delivery + " of " + C.flagged,
    "cold breaches caught in transit", GREEN);
  stat(s, M + 8.25, 5.0, 2.6, "+" + U.utilisation_uplift_pts + " pts",
    "fleet utilisation", GREEN);
}

/* ==================================================================== 2 */
{
  const s = slide("The pain, in three sentences. Do not read the slide — say: " +
    "a disruption is one event but hundreds of consequences; the fleet that could " +
    "absorb it is sitting idle somewhere else; and the cold chain failure is " +
    "discovered at the delivery door, which is the one moment you can do nothing about it.");
  chip(s, "01 / the problem", RED);
  title(s, "One event, hundreds of consequences, zero visibility",
    "Everything below is happening at the same time, in four systems that do not talk to each other.");

  const rows = [
    ["The cascade is invisible", RED,
      "A Suez advisory is one headline. Underneath it sit 65 shipments, 21 of them " +
      "temperature-controlled, spread across four carriers. Nobody can hand-trace that " +
      "before the boxes move."],
    ["The fleet is idle in the wrong place", AMBER,
      "37 assets sat past their idle threshold while other lanes ran short. The carrying " +
      "cost was already spent — " + usd(U.idle_carrying_cost_usd) + " of it — before anyone looked."],
    ["The cold breach is found too late", ICE,
      "A single excursion can spoil a $500K+ cargo. Today it surfaces at the delivery " +
      "door, after the intervention window has closed and the batch record is already wrong."],
  ];
  let y = 2.3;
  rows.forEach(([h, c, body]) => {
    card(s, M, y, W - 2 * M, 1.5);
    s.addShape(pres.ShapeType.ellipse, {
      x: M + 0.32, y: y + 0.36, w: 0.16, h: 0.16, fill: { color: c },
    });
    s.addText(h, {
      x: M + 0.62, y: y + 0.24, w: 4.4, h: 0.42, isTextBox: true, margin: 0,
      fontFace: HEAD, fontSize: 16, bold: true, color: INK, valign: "middle",
    });
    s.addText(body, {
      x: M + 0.62, y: y + 0.68, w: W - 2 * M - 1.1, h: 0.72, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 13, color: MUTE, lineSpacing: 18,
    });
    y += 1.66;
  });
}

/* ==================================================================== 3 */
{
  const s = slide("How it works, one screen. The agent never does arithmetic. " +
    "It picks a tool. The four engines are deterministic Python — same inputs, " +
    "same numbers, every time. That is what makes the output defensible to a regulator.");
  chip(s, "02 / how it works");
  title(s, "One agent, four deterministic engines",
    "The agent decides which tool to call. The engines decide the numbers. Nothing in between.");

  card(s, M, 2.25, W - 2 * M, 0.95, DECK2);
  s.addText("Agent layer — intent routing, guardrails, approval thresholds, narration", {
    x: M + 0.3, y: 2.25, w: 6.9, h: 0.95, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 15, bold: true, color: INK, valign: "middle",
  });
  s.addText("6 registered tools · JSON-schema specs · platform-agnostic adapter", {
    x: W - M - 4.5, y: 2.25, w: 4.2, h: 0.95, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 10.5, color: ICE, align: "right", valign: "middle",
  });

  const eng = [
    ["Exposure", ICE, "Matches live disruptions to every shipment that still has to " +
      "transit an affected node. Ranks by value, SLA headroom, fragility, severity, time-to-choke."],
    ["Re-route", GREEN, "Generates hold / bypass / mode-shift options and scores each on " +
      "expected total cost. Doing nothing always competes."],
    ["Fleet", AMBER, "Flags assets idle past a kind-specific threshold and matches them to " +
      "demand the re-route engine just created."],
    ["Cold chain", RED, "Computes MKT and time-out-of-range from IoT logs, consumes the " +
      "product stability budget, assigns a regulatory severity band."],
  ];
  const cw = (W - 2 * M - 3 * 0.24) / 4;
  eng.forEach(([h, c, body], i) => {
    const x = M + i * (cw + 0.24);
    card(s, x, 3.5, cw, 2.5);
    s.addShape(pres.ShapeType.ellipse, {
      x: x + 0.24, y: 3.76, w: 0.15, h: 0.15, fill: { color: c },
    });
    s.addText(h, {
      x: x + 0.24, y: 4.0, w: cw - 0.48, h: 0.38, isTextBox: true, margin: 0,
      fontFace: HEAD, fontSize: 15, bold: true, color: INK,
    });
    s.addText(body, {
      x: x + 0.24, y: 4.42, w: cw - 0.48, h: 1.44, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 11.5, color: MUTE, lineSpacing: 16,
    });
  });
  s.addText("Every figure the agent speaks is a value an engine returned. The agent is " +
    "replaceable; the arithmetic is not.", {
    x: M, y: 6.2, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, italic: true, color: DIM,
  });
}

/* ==================================================================== 4 */
{
  const s = slide("Engine one. The scoring formula is on the slide because judges will " +
    "ask how we rank. Point out that 109 of 140 shipments are exposed — a raw list is " +
    "useless, which is exactly why the score exists.");
  chip(s, "03 / exposure engine", ICE);
  title(s, "Which shipments does this disruption actually touch?",
    "A shipment is exposed if any node it has not yet cleared is affected. Then it has to be ranked, or the list is noise.");

  card(s, M, 2.3, 6.2, 3.75);
  s.addText("Exposure score", {
    x: M + 0.3, y: 2.5, w: 5.6, h: 0.4, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 15, bold: true, color: INK,
  });
  const weights = [
    ["Value at risk", "30%"], ["Cargo fragility", "22%"],
    ["SLA breach depth", "20%"], ["Disruption severity", "16%"],
    ["Time-to-choke × priority", "12%"],
  ];
  let wy = 3.0;
  weights.forEach(([l, v]) => {
    s.addText(l, {
      x: M + 0.3, y: wy, w: 3.6, h: 0.32, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 13, color: INK, valign: "middle",
    });
    s.addShape(pres.ShapeType.rect, {
      x: M + 3.9, y: wy + 0.11, w: 1.35 * parseFloat(v) / 30, h: 0.1,
      fill: { color: ICE },
    });
    s.addText(v, {
      x: M + 5.3, y: wy, w: 0.6, h: 0.32, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 12, color: MUTE, align: "right", valign: "middle",
    });
    wy += 0.52;
  });
  s.addText("Fragility is class-specific: a vaccine scores 1.00, an automotive casting 0.20.", {
    x: M + 0.3, y: 5.5, w: 5.6, h: 0.4, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 11.5, italic: true, color: DIM,
  });

  const rx = M + 6.5;
  stat(s, rx, 2.3, 2.6, String(K.shipments_exposed) + " / " + K.shipments_monitored,
    "shipments exposed", AMBER);
  stat(s, rx + 2.75, 2.3, 2.6, usdM(K.value_at_risk_usd), "value at risk", AMBER);

  card(s, rx, 3.8, 5.35, 2.0);
  s.addText("Worst incident right now", {
    x: rx + 0.28, y: 3.98, w: 4.8, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 13.5, bold: true, color: INK,
  });
  const top = D.disruption_rollup[0];
  s.addText(top.headline, {
    x: rx + 0.28, y: 4.34, w: 4.8, h: 0.62, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 13, color: INK, lineSpacing: 17,
  });
  s.addText(top.shipments + " shipments  ·  " + usdM(top.value_at_risk) + " at risk  ·  " +
    top.cold_chain + " cold-chain  ·  " + top.sla_breaches + " SLA breaches", {
    x: rx + 0.28, y: 5.05, w: 4.8, h: 0.4, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 11, color: MUTE,
  });
}

/* ==================================================================== 5 */
{
  const s = slide("Engine two, and the slide judges remember. Two points: doing nothing " +
    "is scored as an option, so the model has to beat it; and air capacity is finite, " +
    "so ten shipments got a cheaper-on-paper air option taken away from them. " +
    "That constraint is what stops the demo from just flying everything.");
  chip(s, "04 / re-route engine", GREEN);
  title(s, "Every option competes against doing nothing",
    "Expected total cost = SLA penalty + spoilage risk + incremental freight. Lowest wins.");

  const modes = { air: 0, ocean: 0, rail: 0, road: 0, reroute: 0 };
  D.recommendations.forEach(r => {
    const k = r.recommendation_kind === "reroute" ? "reroute" : r.options[0].mode;
    modes[k] = (modes[k] || 0) + Math.max(0, r.savings_vs_hold_usd);
  });
  s.addChart(pres.ChartType.bar, [{
    name: "Savings vs. hold",
    labels: ["Air shift", "Physical reroute", "Road shift", "Ocean swap", "Rail shift"],
    values: [modes.air, modes.reroute, modes.road, modes.ocean, modes.rail],
  }], {
    x: M, y: 2.3, w: 6.3, h: 3.5,
    barDir: "col", chartColors: [GREEN],
    showTitle: true, title: "Where the savings come from (USD)",
    titleColor: INK, titleFontFace: HEAD, titleFontSize: 13,
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: INK,
    dataLabelFontFace: MONO, dataLabelFontSize: 9, dataLabelFormatCode: '$#,##0,"k"',
    showLegend: false, catAxisLabelColor: MUTE, valAxisLabelColor: MUTE,
    catAxisLabelFontFace: BODY, catAxisLabelFontSize: 10,
    valAxisLabelFontFace: MONO, valAxisLabelFontSize: 9,
    valAxisLabelFormatCode: '$#,##0,,"M"',
    valGridLine: { color: RULE, size: 1 }, catGridLine: { style: "none" },
    plotArea: { fill: { color: SEA } }, chartArea: { fill: { color: SEA } },
  });

  const rx = M + 6.6;
  card(s, rx, 2.3, W - M - rx, 1.55);
  s.addText("The constraint that keeps it honest", {
    x: rx + 0.28, y: 2.48, w: 5.2, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 14, bold: true, color: INK,
  });
  s.addText("Air freight capacity is finite. We allocate it to the shipments where it " +
    "buys the most, and " + D.recommendations.filter(r => r.air_capacity_constrained).length +
    " shipments fell back to a surface option after it ran out.", {
    x: rx + 0.28, y: 2.84, w: 5.2, h: 0.86, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, color: MUTE, lineSpacing: 17,
  });

  const r0 = D.recommendations[0];
  card(s, rx, 4.15, W - M - rx, 1.8);
  s.addText("Worked example — " + r0.shipment_id, {
    x: rx + 0.28, y: 4.33, w: 5.2, h: 0.32, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 12, color: ICE,
  });
  s.addText(r0.recommendation, {
    x: rx + 0.28, y: 4.65, w: 5.2, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 15, bold: true, color: INK,
  });
  s.addText("Costs " + usd(r0.incremental_cost_usd) + " more in freight. Saves " +
    usd(r0.savings_vs_hold_usd) + " against holding. Confidence " +
    Math.round(r0.confidence * 100) + "%.", {
    x: rx + 0.28, y: 5.03, w: 5.2, h: 0.75, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, color: MUTE, lineSpacing: 17,
  });

  s.addText("Total saved across the decision queue: " + usd(K.reroute_savings_usd), {
    x: M, y: 6.05, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 15, bold: true, color: GREEN,
  });
}

/* ==================================================================== 6 */
{
  const s = slide("Engine three. The key insight: idle assets are not a separate problem. " +
    "The re-route engine creates the demand — a box diverted via Durban needs a reefer " +
    "at Durban — and the fleet engine fills it. That link is why the two features belong " +
    "in one product.");
  chip(s, "05 / fleet engine", AMBER);
  title(s, "Idle assets are not a separate problem",
    "The re-route engine creates the demand. The fleet engine fills it with metal that was already paid for.");

  stat(s, M, 2.3, 2.85, String(U.idle_flagged), "assets idle past threshold", AMBER);
  stat(s, M + 3.0, 2.3, 2.85, usd(U.idle_carrying_cost_usd), "carrying cost already burned", RED);
  stat(s, M + 6.0, 2.3, 2.85, String(U.assets_redeployed), "redeployed this cycle", GREEN);
  stat(s, M + 9.0, 2.3, 2.9, usd(U.net_recovery_usd), "net value recovered", GREEN);

  s.addChart(pres.ChartType.bar, [{
    name: "Fleet utilisation",
    labels: ["Before", "After redeployment"],
    values: [U.utilisation_before * 100, U.utilisation_after * 100],
  }], {
    x: M, y: 3.9, w: 5.9, h: 2.5,
    barDir: "col", chartColors: [MUTE, GREEN], varyColors: true,
    showTitle: true, title: "Fleet utilisation (%)", titleColor: INK,
    titleFontFace: HEAD, titleFontSize: 13,
    showValue: true, dataLabelPosition: "outEnd", dataLabelColor: INK,
    dataLabelFontFace: MONO, dataLabelFontSize: 11, dataLabelFormatCode: '0.0"%"',
    showLegend: false, catAxisLabelColor: MUTE, valAxisLabelColor: MUTE,
    catAxisLabelFontFace: BODY, catAxisLabelFontSize: 11,
    valAxisLabelFontFace: MONO, valAxisLabelFontSize: 9, valAxisMaxVal: 100,
    valAxisMajorUnit: 25,
    valGridLine: { color: RULE, size: 1 }, catGridLine: { style: "none" },
    plotArea: { fill: { color: SEA } }, chartArea: { fill: { color: SEA } },
  });

  const rx = M + 6.3;
  card(s, rx, 3.9, W - M - rx, 2.5);
  s.addText("How a match is made", {
    x: rx + 0.3, y: 4.1, w: 5.0, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 14, bold: true, color: INK,
  });
  bullets(s, rx + 0.3, 4.6, 5.0, [
    "A reroute raises a demand signal: reefer box, this node, within 72h",
    "Candidates filtered on reefer capability, capacity and a 4,500km radius",
    "Ranked on value released minus repositioning cost",
    "Assets already at the node move for nothing and win outright",
  ], 11.5, 15);
}

/* ==================================================================== 7 */
{
  const s = slide("Engine four. This is the differentiator. Say it plainly: a threshold " +
    "alarm treats a twenty-minute door-open blip and a nine-hour reefer failure the same " +
    "way, so operators learn to ignore alarms. Mean Kinetic Temperature is what a " +
    "regulator actually asks for, and it is why our severity bands hold up.");
  chip(s, "06 / cold chain engine", RED);
  title(s, "Not an alarm. A classification a regulator would accept.",
    "Mean Kinetic Temperature plus cumulative time-out-of-range, consumed against the product's own stability budget.");

  s.addImage({
    path: path.join(__dirname, "out/fig_trace.png"),
    x: M, y: 2.25, w: 7.6, h: 2.66,
  });

  const rx = M + 7.9;
  const bands = [
    ["RED", RED, C.counts.RED, "Do not distribute. Recall workflow."],
    ["ORANGE", AMBER, C.counts.ORANGE, "Quarantine. Stability assessment."],
    ["AMBER", "D8A55C", C.counts.AMBER, "Release with deviation note."],
    ["GREEN", GREEN, C.counts.GREEN, "Auto-release to batch record."],
  ];
  let by = 2.25;
  bands.forEach(([n, c, count, action]) => {
    card(s, rx, by, W - M - rx, 0.62);
    s.addShape(pres.ShapeType.ellipse, {
      x: rx + 0.22, y: by + 0.25, w: 0.13, h: 0.13, fill: { color: c },
    });
    s.addText(n, {
      x: rx + 0.44, y: by, w: 1.0, h: 0.62, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 11.5, bold: true, color: c, valign: "middle",
    });
    s.addText(String(count), {
      x: rx + 1.4, y: by, w: 0.4, h: 0.62, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 13, bold: true, color: INK, valign: "middle",
    });
    s.addText(action, {
      x: rx + 1.9, y: by, w: 2.5, h: 0.62, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 10.5, color: MUTE, valign: "middle",
    });
    by += 0.72;
  });

  card(s, M, 5.08, 7.6, 1.32);
  s.addText("Why MKT and not a threshold alarm", {
    x: M + 0.3, y: 5.22, w: 7.0, h: 0.32, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 13.5, bold: true, color: INK,
  });
  s.addText("A threshold alarm fires the same way for a 20-minute door-open blip and a " +
    "9-hour reefer failure, so operators learn to ignore it. MKT is the single isothermal " +
    "temperature that would degrade the product as much as the real profile did — it " +
    "separates the two, and it is the number a regulator asks for.", {
    x: M + 0.3, y: 5.56, w: 7.0, h: 0.76, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 11.5, color: MUTE, lineSpacing: 15,
  });

  s.addText(C.caught_pre_delivery + " of " + C.flagged + " flagged shipments were caught " +
    "while still in transit — " + usdM(C.value_protected_usd) + " of cargo with the " +
    "intervention window still open.", {
    x: rx, y: 5.25, w: W - M - rx, h: 1.1, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, color: GREEN, lineSpacing: 17,
  });
}

/* ==================================================================== 8 */
{
  const s = slide("Show, don't tell. Open the dashboard here and run one query live. " +
    "Suggested: 'which vaccine shipments have a temperature problem?' — it routes to " +
    "analyse_cold_chain and returns the RED shipments with hours remaining.");
  chip(s, "07 / the product");
  title(s, "One screen, four answers, no dashboards to stitch",
    "Ask in plain language. The agent picks the tool and quotes what the engine returned.");

  const qs = [
    ["\u201cWhich vaccine shipments have a temperature problem?\u201d",
      "analyse_cold_chain()", RED,
      "Returns RED and ORANGE shipments with MKT, budget consumed, hours to delivery " +
      "and the required disposition."],
    ["\u201cWhat should I do about the Suez diversion?\u201d",
      "assess_disruption_impact()", ICE,
      "Returns the exposed shipments ranked, with the node that blocks each one and how " +
      "many days until it gets there."],
    ["\u201cAny idle containers I can redeploy?\u201d",
      "propose_redeployment()", AMBER,
      "Returns matched assets with distance, cost to move, idle days ended and net benefit."],
  ];
  let y = 2.35;
  qs.forEach(([q, tool, c, body]) => {
    card(s, M, y, W - 2 * M, 1.28);
    s.addText(q, {
      x: M + 0.32, y: y + 0.16, w: 6.2, h: 0.42, isTextBox: true, margin: 0,
      fontFace: HEAD, fontSize: 15, bold: true, color: INK, valign: "middle",
    });
    s.addText("agent \u2192 " + tool, {
      x: W - M - 4.0, y: y + 0.16, w: 3.7, h: 0.42, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 11.5, color: c, align: "right", valign: "middle",
    });
    s.addText(body, {
      x: M + 0.32, y: y + 0.6, w: W - 2 * M - 0.64, h: 0.58, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 12.5, color: MUTE, lineSpacing: 16,
    });
    y += 1.44;
  });
  s.addText("Live demo: sentinelchain_dashboard.html — single file, opens offline, " +
    "no server, no keys.", {
    x: M, y: 6.72, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, italic: true, color: DIM,
  });
}

/* ==================================================================== 9 */
{
  const s = slide("Trust. Judges will probe whether an LLM is inventing numbers. " +
    "The answer is that it cannot: it has read access to tools and write access to " +
    "nothing except a proposal queue, and the arithmetic lives in tested Python.");
  chip(s, "08 / trust");
  title(s, "The agent proposes. It never moves freight.",
    "Guardrails live in code, not in the prompt — a prompt can be talked out of a rule.");

  const g = [
    ["No arithmetic in the model", "Every number comes from a deterministic engine. " +
      "Same inputs, same output, every run — which is what an audit needs."],
    ["Approval thresholds are hard-coded", "Anything above $25,000 incremental spend, " +
      "anything touching a vaccine or frozen biologic, and every RED disposition is a " +
      "proposal that waits for a human."],
    ["Every recommendation carries its numbers", "Dollar delta versus doing nothing, the " +
      "assumption that drove it, and a confidence. No unexplained ranking."],
    ["Write access is a proposal queue", "The agent can read every system and change none " +
      "of them. Notices are drafted, never sent."],
  ];
  const cw = (W - 2 * M - 0.28) / 2;
  g.forEach(([h, b], i) => {
    const x = M + (i % 2) * (cw + 0.28);
    const y = 2.35 + Math.floor(i / 2) * 1.9;
    card(s, x, y, cw, 1.68);
    s.addText(h, {
      x: x + 0.3, y: y + 0.2, w: cw - 0.6, h: 0.38, isTextBox: true, margin: 0,
      fontFace: HEAD, fontSize: 15, bold: true, color: ICE,
    });
    s.addText(b, {
      x: x + 0.3, y: y + 0.62, w: cw - 0.6, h: 0.9, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 12.5, color: MUTE, lineSpacing: 17,
    });
  });
  s.addText(D.recommendations.filter(r => r.requires_human_approval).length +
    " of " + D.recommendations.length + " recommendations in this run were held for " +
    "human sign-off.", {
    x: M, y: 6.3, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 12.5, color: DIM,
  });
}

/* ==================================================================== 10 */
{
  const s = slide("Integration. Say: the tool registry is written as JSON-schema function " +
    "specs, so it drops onto Bob or any tool-calling runtime through one adapter. " +
    "Nothing else in the codebase changes. The offline router exists so the demo runs " +
    "with no network in this room.");
  chip(s, "09 / integration");
  title(s, "Built to drop onto Bob, or anything else",
    "Six tools, written as standard JSON-schema function specs, behind one swappable adapter.");

  card(s, M, 2.3, 6.0, 4.1);
  s.addText("Registered tools", {
    x: M + 0.3, y: 2.48, w: 5.4, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 14, bold: true, color: INK,
  });
  const BLURB = {
    assess_disruption_impact: "Ranks every shipment still facing an affected node.",
    recommend_reroute: "Scores hold, bypass and mode-shift on expected total cost.",
    find_idle_assets: "Lists assets idle past threshold, with carrying cost.",
    propose_redeployment: "Matches idle metal to the demand a reroute just created.",
    analyse_cold_chain: "Computes MKT, time-out-of-range and severity band.",
    draft_stakeholder_notice: "Drafts the customer, QA or carrier notice. Never sends.",
  };
  let ty = 2.92;
  D.tools.forEach(t => {
    s.addText(t.name + "()", {
      x: M + 0.3, y: ty, w: 5.4, h: 0.32, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 12, color: ICE, valign: "middle",
    });
    s.addText(BLURB[t.name], {
      x: M + 0.3, y: ty + 0.3, w: 5.4, h: 0.3, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 10.5, color: MUTE, valign: "middle",
    });
    ty += 0.62;
  });

  const rx = M + 6.3;
  card(s, rx, 2.3, W - M - rx, 1.9);
  s.addText("The seam", {
    x: rx + 0.3, y: 2.48, w: 5.2, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 14, bold: true, color: INK,
  });
  s.addText("PlatformAdapter needs one method: call_model(system, messages, tools). " +
    "Implement it against Bob's runtime and the engines, guardrails and dashboard are " +
    "unchanged. A deterministic offline router ships alongside it so the demo runs with " +
    "no network.", {
    x: rx + 0.3, y: 2.84, w: 5.2, h: 1.2, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 12.5, color: MUTE, lineSpacing: 17,
  });

  card(s, rx, 4.35, W - M - rx, 2.05);
  s.addText("Real data, day one", {
    x: rx + 0.3, y: 4.53, w: 5.2, h: 0.34, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 14, bold: true, color: INK,
  });
  bullets(s, rx + 0.3, 4.88, 5.2, [
    "Shipments and lanes: TMS export or EDI 214 / IFTSTA",
    "Disruptions: carrier advisories, port bulletins, weather APIs",
    "Fleet: telematics feed, keyed on asset ID",
    "Cold chain: reefer IoT loggers over MQTT",
  ], 11.5);
}

/* ==================================================================== 11 */
{
  const s = slide("Honesty slide. Judges trust a team that says what is not real. " +
    "Be quick and matter-of-fact, then move to the close.");
  chip(s, "10 / what is real", DIM);
  title(s, "What is real, and what is not",
    "The dataset is synthetic and seeded. Everything computed on top of it is production logic.");

  const cw2 = (W - 2 * M - 0.3) / 2;
  card(s, M, 2.35, cw2, 3.5);
  s.addText("Real", {
    x: M + 0.3, y: 2.55, w: cw2 - 0.6, h: 0.38, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 16, bold: true, color: GREEN,
  });
  bullets(s, M + 0.3, 2.98, cw2 - 0.6, [
    "All four engines, end to end, in tested Python",
    "MKT computed to the ICH convention, not approximated",
    "Severity rules mapped to named regulatory clauses",
    "Cost model with a real trade-off, including a capacity constraint",
    "Agent tool registry, guardrails and approval thresholds",
    "Single-file dashboard that runs with no server",
  ], 12.5);

  card(s, M + cw2 + 0.3, 2.35, cw2, 3.5);
  s.addText("Not yet", {
    x: M + cw2 + 0.6, y: 2.55, w: cw2 - 0.6, h: 0.38, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 16, bold: true, color: AMBER,
  });
  bullets(s, M + cw2 + 0.6, 2.98, cw2 - 0.6, [
    "Live carrier and telematics connectors — dataset is seeded synthetic",
    "Carrier space is assumed available at the quoted index, not booked",
    "Stability budgets are per class, not per product SKU",
    "Fleet matching is greedy, not a solved optimum",
    "No write-back to TMS; proposals stop at the queue",
  ], 12.5);

  s.addText("Everything in the left column runs in front of you. Nothing in this deck is " +
    "a mock-up.", {
    x: M, y: 6.1, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 13, italic: true, color: DIM,
  });
}

/* ==================================================================== 12 */
{
  const s = slide("Close on the number, then stop talking. The one-line version: " +
    "we find the shipments that matter, we price the alternatives, we put the idle " +
    "metal back to work, and we catch the cold-chain breach while there is still " +
    "something to do about it.");
  chip(s, "11 / the result", GREEN);
  s.addText("One run. One operator. Four decisions that used to take a day.", {
    x: M, y: 1.5, w: 11, h: 0.9, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 30, bold: true, color: INK, lineSpacing: 36,
  });

  s.addText(usdM(K.total_value_defended_usd), {
    x: M, y: 2.75, w: 6.5, h: 1.5, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 72, bold: true, color: GREEN,
  });
  s.addText("of cargo value defended in a single control-tower run", {
    x: M, y: 4.2, w: 6.2, h: 0.5, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 15, color: MUTE,
  });

  const breakdown = [
    ["Re-routing decisions", K.reroute_savings_usd, GREEN],
    ["Cold chain caught in transit", K.cold_chain_value_protected_usd, ICE],
    ["Fleet redeployment", K.fleet_net_recovery_usd, AMBER],
  ];
  let by = 2.75;
  breakdown.forEach(([l, v, c]) => {
    card(s, M + 6.9, by, W - M - (M + 6.9), 0.92);
    s.addText(l, {
      x: M + 7.2, y: by, w: 3.2, h: 0.92, isTextBox: true, margin: 0,
      fontFace: BODY, fontSize: 13, color: INK, valign: "middle",
    });
    s.addText(usdM(v), {
      x: W - M - 2.0, y: by, w: 1.7, h: 0.92, isTextBox: true, margin: 0,
      fontFace: MONO, fontSize: 17, bold: true, color: c,
      align: "right", valign: "middle",
    });
    by += 1.06;
  });

  s.addText("SentinelChain  ·  Challenge L2  ·  run python run_demo.py, then open " +
    "out/sentinelchain_dashboard.html", {
    x: M, y: 6.5, w: W - 2 * M, h: 0.4, isTextBox: true, margin: 0,
    fontFace: MONO, fontSize: 11.5, color: DIM,
  });
}

const outPath = path.join(__dirname, "out", "SentinelChain_Pitch.pptx");
pres.writeFile({ fileName: outPath }).then(() => console.log("wrote", outPath));
