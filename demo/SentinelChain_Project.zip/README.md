# SentinelChain

**Challenge L2 — Supply Chain Disruption Assistant & Fleet Utilisation Optimizer**

An agent that turns four disconnected feeds — disruption advisories, shipment
status, fleet telematics and cold-chain IoT — into one ranked decision queue,
and catches the temperature breach while the truck is still moving.

On the seeded demo dataset a single run defends **$9.99M** of cargo value:
$3.42M from re-routing decisions, $6.17M of cold cargo flagged while the
intervention window is still open, and $401K of fleet capacity put back to work.

---

## Run it

No network, no API keys, no database.

```bash
python3 run_demo.py                 # full pipeline + console narrative
python3 build_dashboard.py          # writes the single-file dashboard
open out/sentinelchain_dashboard.html
```

Ask the agent from the command line:

```bash
python3 run_demo.py --ask "which vaccine shipments have a temperature problem?"
python3 run_demo.py --ask "any idle containers I can redeploy?"
python3 run_demo.py --ask "what should I do about the Suez diversion?"
```

Rebuild the pitch deck (needs Node and `pptxgenjs`):

```bash
python3 make_figures.py && node build_deck.js
```

---

## What's in the box

```
engine/world.py       Seeded synthetic operating picture — 20 network nodes,
                      8 carriers, 140 in-flight shipments, 96 fleet assets,
                      4 live disruptions, 72h of IoT logs per cold shipment
engine/impact.py      Exposure engine — which shipments a disruption touches,
                      and which of those actually matter
engine/reroute.py     Re-route engine — hold / bypass / mode-shift options
                      scored on expected total cost, under an air capacity cap
engine/fleet.py       Fleet engine — idle detection and greedy redeployment
                      against demand the re-route engine just created
engine/coldchain.py   Cold-chain engine — MKT, time-out-of-range, stability
                      budget consumption, regulatory severity classification
engine/agent.py       Tool registry (JSON-schema specs), platform adapter,
                      guardrails, approval thresholds, notice templates
run_demo.py           Orchestrator. Writes out/results.json
build_dashboard.py    Inlines results.json into one self-contained HTML file
build_deck.js         Generates the pitch deck from the same results.json
```

Nothing is hard-coded for the demo. Change the seed in `world.py` and every
number in the dashboard and the deck moves with it.

---

## The four engines in one paragraph each

**Exposure.** A shipment is exposed if any node it has not yet cleared appears
in an active disruption's node set. That alone returns 109 of 140 shipments,
which is useless, so each is scored 0–100 on value at risk (30%), cargo
fragility (22%), SLA breach depth (20%), disruption severity (16%) and
time-to-choke weighted by priority (12%). The operator reads the top twenty.

**Re-route.** For each exposed shipment the engine generates three families of
option — hold, physical bypass, carrier or mode shift — and prices each as
`SLA penalty + spoilage risk + incremental freight`. Holding is always scored,
so the model has to beat doing nothing. Air freight has a value-density floor
and a finite capacity pool allocated to the shipments where it buys the most;
ten shipments in the demo run fall back to a surface option after it runs out.

**Fleet.** Idle assets are flagged against a kind-specific threshold (a reefer
truck idle 18 hours matters; a dry container idle 18 hours does not) and priced
at their accumulated carrying cost. Demand comes from the re-route engine — a
box diverted via Durban needs a reefer at Durban — plus baseline lane
throughput. Matching is greedy on value released minus repositioning cost, so
every pairing can be explained in one line.

**Cold chain.** Sensor logs are parsed into contiguous excursion windows, then
scored on Mean Kinetic Temperature (Haynes, per the ICH convention) and
cumulative time-out-of-range against the product's stability budget. The result
is a GREEN/AMBER/ORANGE/RED band with a named regulatory hook and a required
disposition. A 20-minute door-open blip and a 9-hour reefer failure get
different answers, which is the entire point.

---

## Guardrails

Enforced in code, not in the prompt:

- The agent performs no arithmetic. Every number it speaks came from an engine.
- Anything above $25,000 incremental spend, anything touching a vaccine or
  frozen biologic, and every RED disposition is a proposal that waits for a
  human. 11 of 25 recommendations were held in the demo run.
- Every recommendation carries its dollar delta versus doing nothing, the
  assumption behind it, and a confidence.
- Write access is a proposal queue. Notices are drafted, never sent.

---

## Integration

`engine/agent.py` exposes six tools as standard JSON-schema function specs and
a `PlatformAdapter` with a single method, `call_model(system, messages, tools)`.
Implement that against the target runtime — Bob, a bare tool-calling API, or an
orchestration framework — and the engines, guardrails and dashboard are
unchanged. A deterministic `OfflineRouter` ships alongside it so the demo runs
with no network.

See `docs/ARCHITECTURE.md` for the data contracts and the production data
sources each feed maps to.

---

## Honest limits

The dataset is synthetic and seeded; everything computed on top of it is
production logic. Carrier space is assumed available at the quoted cost index
rather than booked. Stability budgets are per commodity class, not per product
SKU. Fleet matching is greedy rather than a solved optimum. There is no
write-back to a TMS.
